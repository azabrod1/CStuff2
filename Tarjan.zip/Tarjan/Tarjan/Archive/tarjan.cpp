//
//  tarjan.cpp
//  Tarjan
//
//  Created by Alex Zabrodskiy on 4/27/17.
//  Copyright © 2017 Alex Zabrodskiy. All rights reserved.
//

#include "tarjan.hpp"
#include "search.hpp"

