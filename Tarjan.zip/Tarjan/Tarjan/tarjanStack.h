//
//  TarjanStack.h
//  Tarjan
//
//  Created by Alex Zabrodskiy on 4/25/17.
//  Copyright © 2017 Alex Zabrodskiy. All rights reserved.
//

#ifndef TarjanStack_h
#define TarjanStack_h


template <class V>
class TarjanStack {
    
private:
    //Cell<V>* head;
    
public:
    
    
};



#endif /* TarjanStack_h */
